package com.velialiyev.twitterclone.entity;

public enum TweetType {
    TWEET,
    REPLY,
    QUOTE;
}
